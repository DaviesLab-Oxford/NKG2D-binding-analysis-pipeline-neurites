#ifndef anigauss_h
#define anigauss_h

#include <stdio.h>

#endif /* anigauss_h */
